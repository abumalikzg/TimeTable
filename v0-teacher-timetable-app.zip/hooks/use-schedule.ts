"use client"

import { useState, useEffect, useCallback } from "react"
import type { Period, WeekSchedule, TeacherInput } from "@/lib/schedule-utils"
import {
  getScheduleForDay,
  getCurrentPeriod,
  getNextPeriod,
  getRemainingTime,
  isWorkDay,
  getCurrentDayId,
} from "@/lib/schedule-utils"

const STORAGE_KEY = "teacher-timetable-data"

// بيانات الجدول الأسبوعي
const DEFAULT_WEEK_SCHEDULE: WeekSchedule = {
  sunday: {
    1: { subject: "", className: "ثالث 4" },
    2: { subject: "", className: "رابع 5" },
    3: { subject: "", className: "خامس 2" },
    6: { subject: "", className: "رابع 4" },
    7: { subject: "", className: "خامس 1" },
  },
  monday: {
    1: { subject: "", className: "خامس 2" },
    2: { subject: "", className: "خامس 1" },
    3: { subject: "", className: "ثالث 4 (صفوف دنيا)" },
    4: { subject: "", className: "انتظار 1" },
    5: { subject: "", className: "رابع 4" },
    7: { subject: "", className: "رابع 5" },
  },
  tuesday: {
    1: { subject: "", className: "رابع 4" },
    4: { subject: "", className: "انتظار 2" },
    5: { subject: "", className: "ثالث 4" },
    6: { subject: "", className: "انتظار 4" },
    7: { subject: "", className: "رابع 5" },
  },
  wednesday: {
    1: { subject: "", className: "رابع 4" },
    3: { subject: "", className: "انتظار 5" },
    4: { subject: "", className: "خامس 1" },
    5: { subject: "", className: "خامس 2" },
  },
  thursday: {
    2: { subject: "", className: "خامس 2" },
    3: { subject: "", className: "انتظار 1" },
    4: { subject: "", className: "خامس 1" },
    6: { subject: "", className: "رابع 5" },
  },
}

export function useSchedule() {
  const [weekSchedule, setWeekSchedule] = useState<WeekSchedule>(DEFAULT_WEEK_SCHEDULE)
  const [currentPeriod, setCurrentPeriod] = useState<Period | null>(null)
  const [nextPeriod, setNextPeriod] = useState<Period | null>(null)
  const [remainingTime, setRemainingTime] = useState({ minutes: 0, seconds: 0 })
  const [isLoaded, setIsLoaded] = useState(false)
  const [currentDayId, setCurrentDayId] = useState<string>("")

  // الحصول على جدول الحصص حسب اليوم الحالي
  const schedule = getScheduleForDay(currentDayId)

  // Load from localStorage
  useEffect(() => {
    const savedSchedule = localStorage.getItem(STORAGE_KEY)

    if (savedSchedule) {
      try {
        const parsed = JSON.parse(savedSchedule)
        setWeekSchedule({ ...DEFAULT_WEEK_SCHEDULE, ...parsed })
      } catch {
        setWeekSchedule(DEFAULT_WEEK_SCHEDULE)
      }
    }

    setIsLoaded(true)
  }, [])

  // Save to localStorage
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(weekSchedule))
    }
  }, [weekSchedule, isLoaded])

  // Update current period and countdown
  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const dayId = getCurrentDayId(now)
      setCurrentDayId(dayId)
      
      const todaySchedule = getScheduleForDay(dayId)
      const current = getCurrentPeriod(todaySchedule, now)
      const next = getNextPeriod(todaySchedule, now)

      setCurrentPeriod(current)
      setNextPeriod(next)

      if (current) {
        setRemainingTime(getRemainingTime(current.endTime, now))
      } else {
        setRemainingTime({ minutes: 0, seconds: 0 })
      }
    }

    updateTime()
    const interval = setInterval(updateTime, 1000)

    return () => clearInterval(interval)
  }, [])

  const updatePeriodData = useCallback((day: string, periodId: number, data: TeacherInput) => {
    setWeekSchedule((prev) => ({
      ...prev,
      [day]: {
        ...prev[day],
        [periodId]: data,
      },
    }))
  }, [])

  const getPeriodData = useCallback(
    (day: string, periodId: number): TeacherInput | undefined => {
      return weekSchedule[day]?.[periodId]
    },
    [weekSchedule],
  )

  const getCurrentDayData = useCallback((): TeacherInput | undefined => {
    const now = new Date()
    if (!isWorkDay(now) || !currentPeriod || currentPeriod.isBreak) {
      return undefined
    }
    const dayId = getCurrentDayId(now)
    return weekSchedule[dayId]?.[currentPeriod.id]
  }, [weekSchedule, currentPeriod])

  return {
    schedule,
    weekSchedule,
    currentPeriod,
    nextPeriod,
    remainingTime,
    isLoaded,
    updatePeriodData,
    getPeriodData,
    getCurrentDayData,
    currentDayId,
  }
}
